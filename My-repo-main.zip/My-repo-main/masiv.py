import json

table_1 = [
    {"id": 1, "name": "Роза", "color": "Красный", "bloom_season": "Лето", "fragrance_level": "Сильный", "care_difficulty": "Средняя"},
    {"id": 2, "name": "Тюльпан", "color": "Желтый", "bloom_season": "Весна", "fragrance_level": "Слабый", "care_difficulty": "Низкая"},
    {"id": 3, "name": "Орхидея", "color": "Фиолетовый", "bloom_season": "Круглый год", "fragrance_level": "Средний", "care_difficulty": "Высокая"},
    {"id": 4, "name": "Лаванда", "color": "Фиолетовый", "bloom_season": "Лето", "fragrance_level": "Сильный", "care_difficulty": "Низкая"}
]

table_2 = [
    {"id": 1, "Brand": "Boeing", "Model": "747", "Type": "Пассажирский", "FirstFlight": 1969},
    {"id": 2, "Brand": "Airbus", "Model": "A380", "Type": "Пассажирский", "FirstFlight": 2005},
    {"id": 3, "Brand": "Cessna", "Model": "172 Skyhawk", "Type": "Учебный", "FirstFlight": 1955},
    {"id": 4, "Brand": "Lockheed Martin", "Model": "F-35 Lightning II", "Type": "Истребитель", "FirstFlight": 2006}
]

table_3 = [
    {"id": 1, "Profession": "Врач", "Specialization": "Хирург", "EducationYears": 8},
    {"id": 2, "Profession": "Программист", "Specialization": "Backend-разработчик", "EducationYears": 4},
    {"id": 3, "Profession": "Учитель", "Specialization": "Математика", "EducationYears": 5},
    {"id": 4, "Profession": "Архитектор", "Specialization": "Градостроительство", "EducationYears": 6}
]

with open("flowers.json", "w", encoding="utf-8") as f:
    json.dump(table_1, f, ensure_ascii=False, indent=2)

with open("airplanes.json", "w", encoding="utf-8") as f:
    json.dump(table_2, f, ensure_ascii=False, indent=2)

with open("professions.json", "w", encoding="utf-8") as f:
    json.dump(table_3, f, ensure_ascii=False, indent=2)
