import os.path

print("Добро пожаловать в конвертатор текстов в файлы формате .txt")
print("И т.д.")


def create_file():
    filename = input("Введите название вашего будущего файла: ")
    filetext = input("Введите текст вашего будущего файла: ")
    if filename != "" and filetext != "":
        file1 = f'{filename}.txt'
        with open(file1, 'w') as f:
            f.write(filetext)
            print("Файл успешно создан и записан")
    else:
        print("В одном из полей ничего нет")

def read_file():
    b = input("Введите название вашего файла для чтения: ")
    a = os.path.exists(b)
    if a == True:
        with open(b) as f:
            b = f.read()
            print(b)
    else:
        print("Неправильное название файла")

def delete_file():
    b = input("Введите название вашего файла для удаления: ")
    a = os.path.exists(b)
    if a == True:
        print("Вы уверены?")
        print("1) Да")
        print("2) Нет")
        c = int(input("Введите число: "))
        if c == 1:
            os.remove(b)
            with open(b) as f:
                os.remove(b)
                print("Файл удалён")
        elif c == 2:
            print("Ладно")
        else:
            print("Ошибка")
    else:
        print("Неправильное название файла")

while True:
    print("")
    print("Создание файла: 1")
    print("Чтение файла: 2")
    print("Удаление файла: 3")
    a = input("Введите число: ")
    if a == "1":
        create_file()
    elif a == "2":
        read_file()
    elif a == "3":
        delete_file()
