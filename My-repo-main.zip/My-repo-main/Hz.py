import json

FILE_NAME = "clients.json"
def load_clients():
    with open(FILE_NAME, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_clients():
    with open(FILE_NAME, 'w', encoding='utf-8') as file:
        json.dump(clients, file, ensure_ascii=False, indent=2)

clients = load_clients()
def add(name, **data):
    clients.append({'name': name, **data})
    save_clients()
    print(f"Добавлен: {name}")

def find(name=None, **filters):
    for c in clients:
        if name and c['name'] != name:
            continue
        match = all(c.get(k) == v for k, v in filters.items())
        if match:
            return c
    return None

def show():
    for c in clients:
        print(f"\n{c['name']}:")
        for k, v in c.items():
            if k != 'name':
                print(f"  {k}: {v}")
if __name__ == "__main__":
    add("Анна", sketch="flower.jpg")
    add("Дмитрий", appointment="2026-02-15", master="Иван")
    add("Мария", allergies=["latex"], phone="+79991234567")

    print("\nНайден:", find(name="Дмитрий", master="Иван"))
    show()